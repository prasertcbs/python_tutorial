# %%
# # QR code + logo
# ---
# * author:  [Prasert Kanawattanachai](prasert.k@chula.ac.th)
# * YouTube: https://www.youtube.com/prasertcbs
# * [Chulalongkorn Business School](https://www.cbs.chula.ac.th/en/)
# ---

# %%
# pip install Pillow qrcode
import qrcode  # https://pypi.python.org/pypi/qrcode
from PIL import Image  # https://pillow.readthedocs.io/en/stable/reference/Image.html

# %%
def gen_qrcode(text, logo_file=None, logo_pos='c'):
    qr = qrcode.QRCode(
        # About 30% or less errors can be corrected.
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        border=1 # 10px
    )
    qr.add_data(text)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white")
    if logo_file is None:
        return qr_img
    else:
        logo_img = Image.open(logo_file).convert('RGBA')
        qr_logo_img = qr_img.copy().convert('RGBA')
        
        if logo_pos.lower() == 'c':  # center logo
            posx = (qr_img.size[0] - logo_img.size[0]) // 2
            posy = (qr_img.size[1] - logo_img.size[1]) // 2
        else:  # place logo on bottom right (margin 10px)
            margin=10
            posx = qr_img.size[0] - logo_img.size[0] - margin
            posy = qr_img.size[1] - logo_img.size[1] - margin

        qr_logo_img.paste(im=logo_img, box=(posx, posy), mask=logo_img)
        return qr_logo_img


def batch(qr_texts: list, logo_file=None, logo_pos='c'):
    for i, t in enumerate(qr_texts, start=1):
        gen_qrcode(t.strip(), logo_file, logo_pos).save(f'{i}.png')

# %%
if __name__ == '__main__':
    # gen_qrcode("life is beautiful").show()
    # gen_qrcode("life is beautiful").save('qr_sample.png')
    # gen_qrcode("life is beautiful", "happy80x80.png", 'br').show()
    # gen_qrcode("life is beautiful", "happy80x80.png").show()
    # gen_qrcode("life is beautiful", "happy80x80.png").save('qr_logo_center.png')
    # gen_qrcode("life is beautiful ชีวิตสวยงาม", "happy80x80.png", 'br').save('qr_logo_bottom_right.png')
    # gen_qrcode("life is beautiful ชีวิตสวยงาม", "acrobat128x128.png", 'c').save('qr_logo_bottom_right2.png')

    with open('input.txt', 'r') as f:
        qr_texts = f.read().splitlines()
    print(qr_texts)
    # batch(qr_texts, None)
    batch(qr_texts, 'youtube48x48.png', 'br')
